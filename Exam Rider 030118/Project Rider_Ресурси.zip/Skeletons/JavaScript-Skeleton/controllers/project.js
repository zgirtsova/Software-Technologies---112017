const Project = require('../models/Project');

module.exports = {
    index: (req, res) => {
        //TODO: Implement me ...
    },
    createGet: (req, res) => {
        //TODO: Implement me ...
    },
    createPost: (req, res) => {
        //TODO: Implement me ...
    },
    editGet: (req, res) => {
        //TODO: Implement me ...
    },
    editPost: (req, res) => {
        //TODO: Implement me ...
    },
    deleteGet: (req, res) => {
        //TODO: Implement me ...
    },
    deletePost: (req, res) => {
        //TODO: Implement me ...
    }
};