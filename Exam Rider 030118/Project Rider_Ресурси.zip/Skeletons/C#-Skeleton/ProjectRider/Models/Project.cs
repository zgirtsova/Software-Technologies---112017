﻿using System.ComponentModel.DataAnnotations;

namespace ProjectRider.Models
{
    public class Project
    {
        //TODO: Implement me ...
    }
}